<?php
$connection=mysqli_connect('localhost','root','','fitzone') or die("error");

?>