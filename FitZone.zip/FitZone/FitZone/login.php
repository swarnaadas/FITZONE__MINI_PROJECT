<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Form</title>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

<script>
            function loginValid() {
            var a = document.myform.uname.value.trim();
            var b = document.myform.pwd.value.trim();
            if (a == "") {
            document.getElementById("uname").innerHTML = "**Please enter your User Name";
            return false;
            }
            if (b == "") {
            document.getElementById("pwd").innerHTML = "**Please enter your password";
            return false;
            }
            else{ 
              return true;
            }
            }
            function loginClear() {
            document.getElementById("uname").innerHTML = "";
            document.getElementById("pwd").innerHTML = "";
            return false;
            }
    </script>
</head>
<body>

    <div class="main">
        <section class="login">
            <!-- <img src="images/hero-bg.jpg" alt=""> -->
            <div class="container">
                <div class="register-content">
                    <form method="POST" id="login-form" name="myform" class="login-form" onsubmit=" return loginValid();">
                        <h2 class="form-title">LOGIN</h2>
                        
                        <div class="form-group">
                        <label>USER NAME</label>
                            <input type="text"  class="form-input" name="uname" id="uname" placeholder="User Name" autofocus autocomplete = "off" onclick="return loginClear()"/>
                            <span id="uname" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>PASSWORD</label>
                            <input type="password" class="form-input" name="pwd" id="pwd" placeholder="Password" autofocus autocomplete = "off" onclick="return loginClear()"/>
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                            <span id="pwd" style="color:red"></span>

                        </div>

                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Login"/>
                        </div>
                    </form>
                    <p class="loginhere">
                        Don't have an account ? <a href="register.php" >Register Here</a>
                    </p>
                </div>
            </div>
        </section>

    </div>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
    session_start();
    $uname=$_POST['uname'];
    $pwd=$_POST['pwd'];
    $sql=mysqli_query($connection,"SELECT * FROM `tbl_login` WHERE  uname='$uname' and pwd='$pwd'");
    while($row=mysqli_fetch_array($sql))
    {
       if($row['role'] == 'admin')
       {
          $_SESSION['UserID'] = $row['login_id'];
          header("location:admin.php");
       }
       elseif($row['role'] == 'staff')
       {
        $_SESSION['UserID'] = $row['login_id'];
        header("location:staff.php");
       }
       elseif($row['role'] == 'trainer')
       {
        $_SESSION['UserID'] = $row['login_id'];
        header("location:trainer.php");

       }
       elseif($row['role'] == 'physician')
       {
        $_SESSION['UserID'] = $row['login_id'];
        header("location:physician.php");

       }
       elseif($row['role'] =='user')
       {
        $_SESSION['UserID'] = $row['login_id'];
        header("location:user.php");

       }
       else
       {
           header("location:login.php");
       }
         
        }
    }
?>