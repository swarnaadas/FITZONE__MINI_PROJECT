
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Ample lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Ample admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Ample Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>Ample Admin Lite Template by WrapPixel</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/ample-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/plugins/images/favicon.png">
    <!-- Custom CSS -->
    <link href="assets/plugins/bower_components/chartist/dist/chartist.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.css">
    <!-- Custom CSS -->
    <link href="assets/css/style.min.css" rel="stylesheet">
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin6">
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="staff.php">
                        <!-- Logo icon -->
                        <b class="logo-icon">
                            <!-- Dark Logo icon -->
                         <img src="assets/plugins/images/favicon.png" alt="homepage" />
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text -->
                        <span class="logo-text">
                            <p><b><h3>STAFF HOME</h3></B></p>
                            <!-- dark Logo text -->
                            <!-- <img src="assets/plugins/images/logo-text.png" alt="homepage" /> -->
                        </span>
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <a class="nav-toggler waves-effect waves-light text-dark d-block d-md-none"
                        href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                   
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav ms-auto d-flex align-items-center">

                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class=" in">
                            <form role="search" class="app-search d-none d-md-block me-3">
                                <input type="text" placeholder="Search..." class="form-control mt-0">
                                <a href="" class="active">
                                    <i class="fa fa-search"></i>
                                </a>
                            </form>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <li>
                            <a class="profile-pic" href="#">
                                <img src="assets/plugins/images/users/varun.jpg" alt="user-img" width="36"
                                    class="img-circle"><span class="text-white font-medium">Steave</span></a>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                        <li class="sidebar-item pt-2">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="staff.php"
                                aria-expanded="false">
                                <i class="far fa-clock" aria-hidden="true"></i>
                                <span class="hide-menu">Dashboard</span>
                            </a>
                        </li>
                       
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="add_trainer.php"
                                aria-expanded="false">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <span class="hide-menu">Add Trainer</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="add_physician.php"
                                aria-expanded="false">
                                <i class="fa fa-table" aria-hidden="true"></i>
                                <span class="hide-menu">Add Physician</span>
                            </a>
                        </li>
                      
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="login.php"
                                aria-expanded="false">
                                <i class="fa fa-info-circle" aria-hidden="true"></i>
                                <span class="hide-menu">Logout</span>
                            </a>
                        </li>
                        <li class="text-center p-20 upgrade-btn">
                            <a href="https://www.wrappixel.com/templates/ampleadmin/"
                                class="btn d-grid btn-danger text-white" target="_blank">
                                Upgrade to Pro</a>
                        </li>
                    </ul>

                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Dashboard</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="#" class="fw-normal">Dashboard</a></li>
                            </ol>
                            <a href="https://www.wrappixel.com/templates/ampleadmin/" target="_blank"
                                class="btn btn-danger  d-none d-md-block pull-right ms-3 hidden-xs hidden-sm waves-effect waves-light text-white">Upgrade
                                to Pro</a>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
<style>

h2 {
  font-size: 24px;
  text-align: center;
   }

body {
  font-size: 14px;
  line-height: 1.8;
/* background-image: url("pic1.jpg");
  background-size: cover;
  padding: 115px 0;*/ }

.container {
  width: 660px;
  position: relative;
  margin: 0 auto; }

.register-content {
  background: #D3D3D3;
  border-radius: 10px;
  padding: 50px 85px; }

.form-group {
  overflow: hidden;
  margin-bottom: 20px; }

.form-input {
  width: 100%;
  border: 1px ;
  padding: 17px 20px;
   }

.form-input::-webkit-input-placeholder {
    color: #999; }

.form-submit {
  width: 100%;
  border-radius: 5px;
  padding: 17px 20px;
  font-size: 14px;
  border: none;
  background-image: linear-gradient(to left, #74ebd5, #9face6); }


.loginhere {
  color: #555;
  font-weight: 500;
  text-align: center;
}

.loginhere-link {
  font-weight: 700;
  color: #222; }
  </style>


    <div class="main">

        <section class="register">
            <!-- <img src="images/hero-bg.jpg" alt=""> -->
            <div class="container">
                <div class="register-content">
                    <form autocomplete="off" method="POST" id="register-form" name="myform"  class="register-form" onsubmit="return validate();">
                        <h2 class="form-title">ADD TRAINER</h2>
                        
                        <div class="form-group">
                        <label>NAME</label>
                            <input type="text" pattern="[A-Za-z\s]{1,20}" class="form-input" name="t_name" id="t_name" placeholder="Name" onclick="return regclear();"/>
                            <p id="t_namee" style="color:red"></p>          

                        </div>

                        <div class="form-group">
                        <label>PLACE</label>
                            <input type="text" class="form-input" name="t_place" id="t_place" placeholder="Place" onclick="return regclear();"/>
                            <p id="t_placee" style="color:red"></p>          
                        </div>

                        <div class="form-group">
                        <label>PIN</label>
                            <input type="text" class="form-input" name="t_pin" id="t_pin" placeholder="PIN" onclick="return regclear();"/>
                            <p id="t_pinn" style="color:red"></p>          

                        </div>

                        <div class="form-group">
                        <label>GENDER</label>
                            <input type="radio" name="t_gender" value="Male"> Male
                            <input type="radio" name="t_gender" value="Female"> Female

                        </div>

                        <div class="form-group">
                        <label>E-MAIL</label>
                            <input type="text" class="form-input" name="t_email" id="t_email" placeholder="Email" onclick="return regclear();"/>
                            <p id="t_emaill" style="color:red"></p>          

                        </div>

                        <div class="form-group">
        
        <label>CERTIFICATION</label>
        <select id="certification" name="certification" class="form-control" required>
          <option value="select" selected disabled>select</option> 
          <option value="NCCPT">NCCPT – National Council for Certified Personal Trainers</option>
          <option value="NFPT">NFPT – National Federation of Professional Trainers</option>
          <option value="FM">FM – Fitness Mentors</option>
          <option value="ISSA">ISSA – International Sports Sciences Association</option>
          <option value="ACE">ACE – The American Council on Exercise</option>
          <option value="NCSF"> NCSF – National Council on Strength & Fitness</option>
          <option value="AFAA">AFAA – Athletics and Fitness Association of America</option>
          <option value="ACSM">ACSM – American College of Sports Medicine</option>
          <option value="NSCA"> NSCA – National Strength and Conditioning Association</option>
          </select>
          <p id="certificationn" style="color:red"></p>          
      </div>

                        <div class="form-group">
                         <label>PHONE NUMBER</label>
                            <input type="number" class="form-input" name="t_phone" id="t_phone" placeholder="Phone Number" onclick="return regclear();"/>
                            <p id="t_phonee" style="color:red"></p>          
                        </div>

                        <div class="form-group">
                            <label>EXPERIENCE</label>
                    <select id="t_experience" name="t_experience" class="form-control" required>
      <option value="select" selected disabled>select</option> 
      <option>1 Yr</option>
      <option >2 Yr</option>
      <option>3 Yr</option>
      <option value="4 Yr and Above">4 Yr and Above</option>
</select>
                            <p id="t_experiencee" style="color:red"></p>          
                        </div>


                        <div class="form-group">
                         <label>AADHAR NUMBER</label>
                            <input type="number" class="form-input" name="t_aadhar" id="t_aadhar" placeholder="Aadhar Number" onclick="return regclear();"/>
                            <p id="t_aadharr" style="color:red"></p>
                        </div>
                    
                        <div class="form-group">
                         <label>UPLOAD AADHAR</label>
                            <input type="file" class="form-input" name="t_upaadhar" id="t_upaadhar" placeholder="" onclick="return regclear();"/>
                            <p id="t_upaadharr" style="color:red"></p>
                        </div>
 
                         <div class="form-group">
                        <label>USER NAME</label>
                            <input type="text" class="form-input" name="uname" id="uname" placeholder="E-Mail Id" onclick="return regclear();"/>  
                            <p id="unamee" style="color:red"></p>
                       
                        </div>

                        <div class="form-group">
                        <label>PASSWORD</label>
                            <input type="password" class="form-input" name="pwd" id="pwd" placeholder="Password" onclick="return regclear();"/>
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>    
                            <p id="pwdd" style="color:red"></p>          
                        </div> 
                        
			
		  
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="ADD TRAINER"/>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
   
    <footer class="footer text-center"> 2022 © FitZone Site brought to you by <a
                    href="https://www.wrappixel.com/">fitzonee.com</a>
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/app-style-switcher.js"></script>
    <script src="assets/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!--Wave Effects -->
    <script src="assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="assets/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="assets/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="assets/plugins/bower_components/chartist/dist/chartist.min.js"></script>
    <script src="assets/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/js/pages/dashboards/dashboard1.js"></script>
</body>

</html>
<script type="text/javascript">
    function validate(){

        // var a = document.myform.name.value.trim();
        var a= document.getElementById('t_name').value.trim();
        var b= document.getElementById('t_place').value.trim();
        var c= document.getElementById('t_pin').value.trim();
        var d= document.getElementById('t_email').value.trim();
        var e= document.getElementById('certification').value.trim();
        var f= document.getElementById('t_phone').value.trim();
        var g= document.getElementById('t_experience').value.trim();
        var h= document.getElementById('t_aadhar').value.trim();
        var i= document.getElementById('t_upaadhar').value.trim();
        var j= document.getElementById('uname').value.trim();
        var k= document.getElementById('pwd').value.trim();
        var l= document.getElementById('cpwd').value.trim();



        if(a=="")
        {
            document.getElementById('t_namee').innerHTML="Please enter the Name !!";
            return false;
        }

        if (!a.match(/^[A-Za-z]/)) 
       {
        document.getElementById('t_namee').innerHTML=" Only alphabets are allowed!!";
        document.getElementById('t_namee').value = "";
        return false;
       }


        if(b=="")
        {
            document.getElementById('t_placee').innerHTML="Please enter the Place !!";
            return false;
        }
         if (!b.match(/^[A-Za-z]/)) 
       {
        document.getElementById('t_placee').innerHTML=" Only alphabets are allowed!!";
        document.getElementById('t_placee').value = "";
        return false;
       }

        if(c=="")
        {
            document.getElementById('t_pinn').innerHTML="Please enter the Pin Number !!";
            return false;
        }

       
        if(d=="")
        {
            document.getElementById('t_emaill').innerHTML="Please enter the E-Mail Address !!";
               return false;
           }
            if (!d.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
     {
        document.getElementById('t_emaill').innerHTML="Enter a Valid Email";
        document.getElementById('t_emaill').value = "";
            return false;
        }

        if(e=="")
        {
            document.getElementById('certificationn').innerHTML="Please enter the Date of Birth !!";
            return false;
        }

         if(f=="")
        {
            document.getElementById('t_phonee').innerHTML="Please enter the Phone Number !!";
            return false;
        }
       if (!f.match(/^[0-9]{10}/)) 
        {
         document.getElementById('t_phonee').innerHTML=" Please enter a 10 digit Phone Number!!";
         document.getElementById('t_phonee').value = "";
        return false;
        }

        if(g=="")
        {
            document.getElementById('t_experiencee').innerHTML="Please enter the Experience !!";
            return false;
        }

        if(h=="")
        {
            document.getElementById('t_aadhar').innerHTML="Please enter the Aadhar Number !!";
            return false;
        }
        if (!h.match(/^[0-9]{12}/)) 
        {
         document.getElementById('t_aadharr').innerHTML=" Please enter a 12 digit Phone Number!!";
         document.getElementById('t_aadharr').value = "";
        return false;
        }

        if(i=="")
        {
            document.getElementById('t_upaadharr').innerHTML="Please Upload Aadhar Card !!";
            return false;
        }        

         if(j=="")
        {
            document.getElementById('unamee').innerHTML="Please enter the User Name !!";
            return false;
        }

         if(k=="")
        {
            document.getElementById('pwdd').innerHTML="Please enter the Password !!";
            return false;
        }
    //     if (!h.match(/^[A-Za-z0-9!-*]{6,15}$/)) 
    // {
    //     document.getElementById('pwdd').innerHTML="Password should contain atleast 6 characters !!";
        
    //          document.getElementById('pwdd').value = "";
    //     return false;
    // }

         if(l=="")
        {
            document.getElementById('cpwdd').innerHTML="Please enter the Confirm Password !!";
            return false;
        }
        //  if(document.getElementById('pwdd').value != document.getElementById('cpwdd').value)
        // {
        //     alert("Passwords Should Match");
        //      document.getElementById('cpwdd').value = "";
        // }
        

    //     if(h.value!=i.value)
    // {
    //     document.getElementById('cpwdd').innerHTML="Passwords does not match!!";
    //  document.getElementById('cpwdd').value = "";
    //     return false;
    // }

        //  if(j=="")
        // {
        //     document.getElementById('rolee').innerHTML="Please select the Role !!";
        //     return false;
        // }

        else
        {
            return true;
        }
    }
    function regclear()
    {
        document.getElementById('t_namee').innerHTML="";
        document.getElementById('t_placee').innerHTML="";
        document.getElementById('t_pinn').innerHTML="";
        document.getElementById('t_emaill').innerHTML="";
        document.getElementById('certificationn').innerHTML="";
        document.getElementById('t_phonee').innerHTML="";
        document.getElementById('t_experiencee').innerHTML="";
        document.getElementById('t_aadharr').innerHTML="";
        document.getElementById('t_upaadharr').innerHTML="";
        document.getElementById('unamee').innerHTML="";
        document.getElementById('pwdd').innerHTML="";
        document.getElementById('cpwdd').innerHTML="";

    }
</script>


<?php
include 'connection.php';
?>
<?php
if(isset($_POST['submit']))
{
    $t_name = $_POST['t_name'];
    $t_place=$_POST['t_place'];
    $t_pin = $_POST['t_pin'];
    $t_gender=$_POST['t_gender'];
    $t_email=$_POST['t_email'];
    $certification=$_POST['certification'];
    $t_phone=$_POST['t_phone'];
    $t_experience=$_POST['t_experience'];
    $t_aadhar=$_POST['t_aadhar'];
    $t_upaadhar=$_POST['t_upaadhar'];
	$uname=$_POST['uname'];
    $pwd=$_POST['pwd'];
    $role=$_POST['role'];
    // $ts_name=$_POST['ts_name'];
    // $ts_day=$_POST['ts_day'];
    // $ts_time=$_POST['ts_time'];


    // $s=mysqli_query($connection,"INSERT INTO `t_schedule`(`ts_name`, `ts_day`, `ts_time`) VALUES ('[value-2]','[value-3]','[value-4]')");
    $sql=mysqli_query($connection,"INSERT INTO `tbl_login`( `uname`, `pwd`, `role`) VALUES ('$uname','$pwd','$role')");
    $roleid=mysqli_insert_id($connection);
    $sq=mysqli_query($connection,"INSERT INTO `add_trainer`( `login_id`, `t_name`, `t_place`, `t_pin`, `t_gender`, `t_email`, `certification`, `t_phone`,`t_experience`,`t_aadhar`,`t_upaadhar`) VALUES ('$roleid','$t_name','$t_place','$t_pin','$t_gender','$t_email','$certification','$t_phone','$t_experience','$t_aadhar','$t_upaadhar')");
  // @header("location:login.php");
echo "<script>location='login.php'</script>";
}
?>