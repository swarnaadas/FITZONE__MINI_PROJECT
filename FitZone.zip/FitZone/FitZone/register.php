<?php
    include 'connection.php';
?>
<html>
<head>
    <title>User Registration</title>
        <link rel="stylesheet" href="css/style.css">

</head>

<body>
    <div class="main">

        <section class="register">
            <!-- <img src="images/hero-bg.jpg" alt=""> -->
            <div class="container">
                <div class="register-content">
                    <form autocomplete="off" method="POST" id="register-form" name="myform"  class="register-form" onsubmit="return validate();">
                        <h2 class="form-title">USER REGISTER</h2>
                        
                        <div class="form-group">
                        <label>NAME</label>
                            <input type="text" class="form-input" name="name" id="name" placeholder="Your Name" onclick="return regclear();" />
                        <p id="namee" style="color:red"></p>
                        </div>

                        <div class="form-group">
                        <label>PLACE</label>
                            <input type="text" class="form-input" name="place" id="place" placeholder="Your Place" onclick="return regclear();" />
                        <p id="placee" style="color:red"></p>
                        </div>

                         <div class="form-group">
                        <label>PIN</label>
                            <input type="number" class="form-input" name="pin" id="pin" placeholder="Your PIN" onclick="return regclear();" />
                        <p id="pinn" style="color:red"></p>
                        </div>

                      <div class="form-group">
                        <label>GENDER</label>
                            <input type="radio"  name="gender" value="Male" checked> Male
                            <input type="radio" name="gender" value="Female" > Female
                        </div>

                       <div class="form-group">
                        <label>E-MAIL</label>
                            <input type="email" class="form-input" name="email" id="email" placeholder="Your Email" onclick="return regclear();"/>
                        <p id="emaill" style="color:red"></p>
                        </div>

                          <div class="form-group">
                        <label>DATE OF BIRTH</label>
                            <input type="date" min="1980-01-01" max="2010-12-30" class="form-input" name="dob" id="dob" max="<?php echo date("Y-m-d")?>" onclick="return regclear();"/>
                         <p id="dobb" style="color:red"></p>

                                </div>

                     <div class="form-group">
                         <label>PHONE NUMBER</label>
                            <input type="number" class="form-input" name="phone" id="phone" placeholder="Your Phone Number" onclick="return regclear();"/>
                         <p id="phonee" style="color:red"></p>

                        </div>

                        <div class="form-group">
                        <label>USER NAME</label>
                            <input type="text"  class="form-input" name="uname" id="uname" placeholder="Your E-Mail"onclick="return regclear();"/>  
                         <p id="unamee" style="color:red"></p>
                       
                        </div>
                        <div class="form-group">
                        <label>PASSWORD</label>
                            <input type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}" title="password must contain at least 1 number & 1 uppercase & lowercase letter & atleast 5 or more characters" class="form-input" name="pwd" id="pwd" placeholder="Password" />
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>    
                         <p id="pwdd" style="color:red"></p>
                        </div>

                        <div class="form-group">
                        <label>CONFIRM PASSWORD</label>
                            <input type="password" class="form-input" name="cpwd" id="cpwd" placeholder="Confirm password" onclick="return regclear();"/> 
                         <p id="cpwdd" style="color:red"></p>
                        </div>
                       
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Register"/>
                        </div>

                          </form>
                    <p class="loginhere">
                        Have already an account ? <a href="login.php" class="loginhere-link">Login Here</a>
                    </p>
                   
               </div>
            </div>
        </section>
    </div>


</body>
</html>
     <script type="text/javascript">
    function validate(){

        // var a = document.myform.name.value.trim();
        var a= document.getElementById('name').value.trim();
        var b= document.getElementById('place').value.trim();
        var c= document.getElementById('pin').value.trim();
        var d= document.getElementById('email').value.trim();
        var e= document.getElementById('dob').value.trim();
        var f= document.getElementById('phone').value.trim();
        var g= document.getElementById('uname').value.trim();
        var h= document.getElementById('pwd').value.trim();
        var i= document.getElementById('cpwd').value.trim();
       // var j= document.getElementById('role').value.trim();



        if(a=="")
        {
            document.getElementById('namee').innerHTML="Please enter the Name !!";
            return false;
        }

        if (!a.match(/^[A-Za-z]/)) 
       {
        document.getElementById('namee').innerHTML=" Only alphabets are allowed!!";
        document.getElementById('namee').value = "";
        return false;
       }


        if(b=="")
        {
            document.getElementById('placee').innerHTML="Please enter the Place !!";
            return false;
        }
         if (!b.match(/^[A-Za-z]/)) 
       {
        document.getElementById('placee').innerHTML=" Only alphabets are allowed!!";
        document.getElementById('placee').value = "";
        return false;
       }

        if(c=="")
        {
            document.getElementById('pinn').innerHTML="Please enter the Pin Number !!";
            return false;
        }

       
        if(d=="")
        {
            document.getElementById('emaill').innerHTML="Please enter the E-Mail Address !!";
               return false;
           }
            if (!d.match(/([A-z0-9_\-\.]){1,}\@([A-z0-9_\-\.]){1,}\.([A-Za-z]){2,4}$/)) 
     {
        document.getElementById('emaill').innerHTML="Enter a Valid Email";
        document.getElementById('emaill').value = "";
            return false;
        }

        if(e=="")
        {
            document.getElementById('dobb').innerHTML="Please enter the Date of Birth !!";
            return false;
        }

         if(f=="")
        {
            document.getElementById('phonee').innerHTML="Please enter the Phone Number !!";
            return false;
        }
       if (!f.match(/^[0-9]{10}/)) 
        {
         document.getElementById('phonee').innerHTML=" Please enter a 10 digit phone Number!!";
         document.getElementById('phonee').value = "";
        return false;
        }

         if(g=="")
        {
            document.getElementById('unamee').innerHTML="Please enter the User Name !!";
            return false;
        }

         if(h=="")
        {
            document.getElementById('pwdd').innerHTML="Please enter the Password !!";
            return false;
        }
    //     if (!h.match(/^[A-Za-z0-9!-*]{6,15}$/)) 
    // {
    //     document.getElementById('pwdd').innerHTML="Password should contain atleast 6 characters !!";
        
    //          document.getElementById('pwdd').value = "";
    //     return false;
    // }

         if(i=="")
        {
            document.getElementById('cpwdd').innerHTML="Please enter the Confirm Password !!";
            return false;
        }
        //  if(document.getElementById('pwdd').value != document.getElementById('cpwdd').value)
        // {
        //     alert("Passwords Should Match");
        //      document.getElementById('cpwdd').value = "";
        // }
        

    //     if(h.value!=i.value)
    // {
    //     document.getElementById('cpwdd').innerHTML="Passwords does not match!!";
    //  document.getElementById('cpwdd').value = "";
    //     return false;
    // }

        //  if(j=="")
        // {
        //     document.getElementById('rolee').innerHTML="Please select the Role !!";
        //     return false;
        // }

        else
        {
            return true;
        }
    }
    function regclear()
    {
        document.getElementById('namee').innerHTML="";
        document.getElementById('placee').innerHTML="";
        document.getElementById('pinn').innerHTML="";
        document.getElementById('emaill').innerHTML="";
        document.getElementById('dobb').innerHTML="";
        document.getElementById('phonee').innerHTML="";
        document.getElementById('unamee').innerHTML="";
        document.getElementById('pwdd').innerHTML="";
        document.getElementById('cpwdd').innerHTML="";
        document.getElementById('rolee').innerHTML="";

    }
</script>



<?php
if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $place=$_POST['place'];
    $pin = $_POST['pin'];
    $gender=$_POST['gender'];
    $email=$_POST['email'];
    $dob=$_POST['dob'];
    $phone=$_POST['phone'];
    $uname=$_POST['uname'];
    $pwd=$_POST['pwd'];
    $role=$_POST['role'];

    
    $sql=mysqli_query($connection,"INSERT INTO `tbl_login`( `uname`,`pwd`,`role`) VALUES ('$uname','$pwd)','$role')");
    $roleid=mysqli_insert_id($connection);
    $sq=mysqli_query($connection,"INSERT INTO `user_reg`( `login_id`, `name`, `place`, `pin`, `gender`, `email`, `dob`, `phone`) VALUES ('$roleid','$name','$place','$pin','$gender','$email','$dob','$phone')");
  // @header("location:login.php");
echo "<script>location='login.php'</script>";
}
?>
