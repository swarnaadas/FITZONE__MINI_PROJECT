<html>
<head>
	<title>registration</title>
</head>

<body>
<form method="post" name="myform" onsubmit="return registration();" action="#">
<label>name</label>
<input type="text" name="name" id="name" placeholder="enter the name" onclick="return regclear();">
<p id="n1" style="color:red"></p>
<!-- <span id="name" style="color:red"></span> -->
<br>
<label>place</label>
<input type="text" name="place" id="place" placeholder="enter the place" onclick="return regclear();">
<span id="place" style="color:red"></span>
<br>
<input type="submit" name="button" value="register">
</form>

</body>
</html>
     <script type="text/javascript">
    function registration(){

        var a = document.myform.name.value;
        var b = document.myform.name.value.trim();
        // var c= document.getElementById('pin').value.trim();

        if(a=="")
        {
            document.getElementById('n1').innerHTML="Please ente the name";
            return false;
        }
        if(b == "")
        {
            document.getElementById('place').innerHTML="Please ente the place";
            return false;
        }
        // if(c =="")
        // {
        //     document.getElementById('pin').innerHTML="Please ente the pin number";
        //     return false;
        // }
        else
        {
            return true;
        }
    }
    function regclear()
    {
        document.getElementById('n1').innerHTML="";
        document.getElementById('place').innerHTML="";
        // document.getElementById('pin').innerHTML="";
    }
</script>