
<?php
include 'connection.php';
?>
<html>
<head>
    <title>Add Physician</title>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- <script type="text/javaScript">

 function validate()  
          {  
               if (document.myform.name.value.trim()=="")
                {
                 alert("Please put your name");
                 document.myform.name.focus();
                 return false;
                }

                if (document.myform.place.value.trim() =="" )
                {
                 alert("Please put  your place");
                 document.myform.place.focus();
                 return false;
                }
                if (document.myform.pin.value.trim() =="")
                {
                 alert("Please put your 6 digit pin number");
                 document.myform.pin.focus();
                 return false;
                }
                
                var x=document.myform.email.value;   
                var atposition=x.indexOf("@");  
                var dotposition=x.lastIndexOf(".");  
                if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length)
                  {  
                    alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
                    return false;   
                  }

                 if (document.myform.gender.value.trim()== false)
                 {
                  alert("Please put your gender");
                  document.myform.gender.focus();
                  return false;
                 }

               if (document.myform.dob.value =="" )
                {
                 alert("Please put your  date of birth as MM/DD/YYYY");
                 document.myform.dob.focus();
                 return false;
                }

                if (document.myform.phone.value.trim()=="")
                 {
                   alert("Please put your phone number");
                   document.myform.phone.focus();
                   return false;
                 } 
                  if (document.myform.phone.value.length < 10 || document.myform.phone.value.length > 10 )
                 {
                   alert("Please put your 10 digit phone number");
                   document.myform.phno.focus();
                   return false;
                 }  

                 if (document.myform.uname.value.trim() =="")
                 {
                 alert("Please put your user name");
                 document.myform.uname.focus();
                 return false;
                 }
                 
                if (document.myform.pwd.value.trim() =="" )
                 {
                 alert("Please put your password");
                 document.myform.pwd.focus();
                 return false;
                 }
                 if (document.myform.cpwd.value.trim() =="")
                 {
                 alert("Please put your confirm password");
                 document.myform.cpwd.focus();
                 return false;
                 }
                else if (document.myform.pwd.value != document.myform.cpwd.value )
                 {
                 alert("Please put same password");
                 document.myform.cpwd.focus();
                 return false;
                 }
                 if (document.myform.role.value.trim() =="" ||document.myform.role.value =="select"  )
                {
                 alert("Please select  your role");
                 document.myform.role.focus();
                 return false;
                }
                else {
                return true;  
                }
          }
          </script> -->

</head>
<body>

    <div class="main">

        <section class="register">
            <!-- <img src="images/hero-bg.jpg" alt=""> -->
            <div class="container">
                <div class="register-content">
                    <form autocomplete="off" method="POST" id="register-form" name="myform"  class="register-form" onsubmit="return validate();">
                        <h2 class="form-title">ADD PHYSICIAN</h2>
                        
                        <div class="form-group">
                        <label>NAME</label>
                            <input type="text" pattern="[A-Za-z\s]{1,20}" class="form-input" name="p_name" id="p_name" placeholder="Name" />
                            <span id="p_name" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>PLACE</label>
                            <input type="text" class="form-input" name="p_place" id="p_place" placeholder="Place" />
                            <span id="p_place" style="color:red"></span>    
                        </div>

                        <div class="form-group">
                        <label>PIN</label>
                            <input type="text" class="form-input" name="p_pin" id="p_pin" placeholder="PIN" />
                            <span id="p_pin" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>GENDER</label>
                            <input type="radio" name="p_gender" > Male
                            <input type="radio" name="p_gender" > Female
                            <span id="p_gender" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>E-MAIL</label>
                            <input type="text" class="form-input" name="p_email" id="p_email" placeholder="Email" />
                            <span id="p_email" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>QUALIFICATION</label>
                            <input type="text" class="form-input" name="p_qualification" id="p_qualification" placeholder="Qualification" />
                            <span id="p_qualification" style="color:red"></span>
                        </div>

                        <div class="form-group">
                         <label>PHONE NUMBER</label>
                            <input type="number" class="form-input" name="p_phone" id="p_phone" placeholder="Phone Number" />
                            <span id="p_phone" style="color:red"></span>
                        </div>

                        <div class="form-group">
                        <label>EXPERIENCE</label>
                            <input type="text" class="form-input" name="p_experience" id="p_experience" placeholder="Experience" />
                            <span id="p_experience" style="color:red"></span>
                        </div>

                        <div class="form-group">
                         <label>LICENSE NUMBER</label>
                            <input type="number" class="form-input" name="license_no" id="license_no" placeholder="License Number" />
                            <span id="license_no" style="color:red"></span>
                        </div>
                    
                        <div class="form-group">
                         <label>UPLOAD LICENSE</label>
                            <input type="file" class="form-input" name="up_license" id="up_license" placeholder="" />
                            <span id="up_license" style="color:red"></span>
                        </div>
 
                         <div class="form-group">
                        <label>USER NAME</label>
                            <input type="text" class="form-input" name="uname" id="uname" placeholder="5 Digit Id"/>  
                            <span id="uname" style="color:red"></span>
                       
                        </div>

                        <div class="form-group">
                        <label>PASSWORD</label>
                            <input type="password" class="form-input" name="pwd" id="pwd" placeholder="Password" />
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>    
                            <span id="pwd" style="color:red"></span>          
                        </div> 
                        
						 <div class="form-group">
        
            <label>ROLE</label>
            <select id="role" name="role" class="form-control" required>
              <option value="select" selected disabled>select</option> 
              <option value="physician">PHYSICIAN</option>
              </select>
              <span id="role"></span>
          </div>
		  
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="ADD PHYSICIAN"/>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
   
   

</body>
</html>
<?php
if(isset($_POST['submit']))
{
    $p_name = $_POST['p_name'];
    $p_place=$_POST['p_place'];
    $p_pin = $_POST['p_pin'];
    $p_gender=$_POST['p_gender'];
    $p_email=$_POST['p_email'];
    $p_qualification=$_POST['p_qualification'];
    $p_phone=$_POST['p_phone'];
    $p_experience=$_POST['p_experience'];
    $license_no=$_POST['license_no'];
    $up_license=$_POST['up_license'];
	$uname=$_POST['uname'];
    $pwd=$_POST['pwd'];
    $role=$_POST['role'];

    
    $sql=mysqli_query($connection,"INSERT INTO `tbl_login`( `uname`,`pwd`,`role`) VALUES ('$uname','$pwd','$role')");
    $roleid=mysqli_insert_id($connection);
    $sq=mysqli_query($connection,"INSERT INTO `add_physician`( `login_id`, `t_name`, `t_place`, `t_pin`, `t_gender`, `t_email`, `t_qualification`, `t_phone`,`t_experience`,`license_no`,`up_license`) VALUES ('$roleid','$t_name','$t_place','$t_pin','$t_gender','$t_email','$t_qualification','$t_phone','$t_experience','$license_no','$up_license')");
  // @header("location:login.php");
echo "<script>location='login.php'</script>";
}
?>