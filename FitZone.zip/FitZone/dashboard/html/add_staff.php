
<?php
include 'connection.php';
?>
<html>
<head>
    <title>Add Staff</title>

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- <script type="text/javaScript">

 function validate()  
          {  
               if (document.myform.name.value.trim()=="")
                {
                 alert("Please put your name");
                 document.myform.name.focus();
                 return false;
                }

                if (document.myform.place.value.trim() =="" )
                {
                 alert("Please put  your place");
                 document.myform.place.focus();
                 return false;
                }
                if (document.myform.pin.value.trim() =="")
                {
                 alert("Please put your 6 digit pin number");
                 document.myform.pin.focus();
                 return false;
                }
                
                var x=document.myform.email.value;   
                var atposition=x.indexOf("@");  
                var dotposition=x.lastIndexOf(".");  
                if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length)
                  {  
                    alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
                    return false;   
                  }

                 if (document.myform.gender.value.trim()== false)
                 {
                  alert("Please put your gender");
                  document.myform.gender.focus();
                  return false;
                 }

               if (document.myform.dob.value =="" )
                {
                 alert("Please put your  date of birth as MM/DD/YYYY");
                 document.myform.dob.focus();
                 return false;
                }

                if (document.myform.phone.value.trim()=="")
                 {
                   alert("Please put your phone number");
                   document.myform.phone.focus();
                   return false;
                 } 
                  if (document.myform.phone.value.length < 10 || document.myform.phone.value.length > 10 )
                 {
                   alert("Please put your 10 digit phone number");
                   document.myform.phno.focus();
                   return false;
                 }  

                 if (document.myform.uname.value.trim() =="")
                 {
                 alert("Please put your user name");
                 document.myform.uname.focus();
                 return false;
                 }
                 
                if (document.myform.pwd.value.trim() =="" )
                 {
                 alert("Please put your password");
                 document.myform.pwd.focus();
                 return false;
                 }
                 if (document.myform.cpwd.value.trim() =="")
                 {
                 alert("Please put your confirm password");
                 document.myform.cpwd.focus();
                 return false;
                 }
                else if (document.myform.pwd.value != document.myform.cpwd.value )
                 {
                 alert("Please put same password");
                 document.myform.cpwd.focus();
                 return false;
                 }
                 if (document.myform.role.value.trim() =="" ||document.myform.role.value =="select"  )
                {
                 alert("Please select  your role");
                 document.myform.role.focus();
                 return false;
                }
                else {
                return true;  
                }
          }
          </script> -->

</head>
<body>

    <div class="main">

        <section class="register">
            <!-- <img src="images/hero-bg.jpg" alt=""> -->
            <div class="container">
                <div class="register-content">
                    <form autocomplete="off" method="POST" id="register-form" name="myform"  class="register-form" onsubmit="return validate();">
                        <h2 class="form-title">ADD STAFF</h2>
                        
                        <div class="form-group">
                        <label>NAME</label>
                            <input type="text" pattern="[A-Za-z\s]{1,20}" class="form-input" name="s_name" id="s_name" placeholder="Name" />
                            <span id="s_name" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>PLACE</label>
                            <input type="text" class="form-input" name="s_place" id="s_place" placeholder="Place" />
                            <span id="s_place" style="color:red"></span>    
                        </div>

                        <div class="form-group">
                        <label>PIN</label>
                            <input type="text" class="form-input" name="s_pin" id="s_pin" placeholder="PIN" />
                            <span id="s_pin" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>GENDER</label>
                            <input type="radio" name="s_gender" > Male
                            <input type="radio" name="s_gender" > Female
                            <span id="s_gender" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>E-MAIL</label>
                            <input type="text" class="form-input" name="s_email" id="s_email" placeholder="Email" />
                            <span id="s_email" style="color:red"></span>

                        </div>

                        <div class="form-group">
                        <label>QUALIFICATION</label>
                            <input type="text" class="form-input" name="s_qualification" id="s_qualification" placeholder="Qualification" />
                            <span id="s_qualification" style="color:red"></span>
                        </div>

                        <div class="form-group">
                         <label>PHONE NUMBER</label>
                            <input type="number" class="form-input" name="s_phone" id="s_phone" placeholder="Phone Number" />
                            <span id="s_phone" style="color:red"></span>
                        </div>

                        <div class="form-group">
                        <label>EXPERIENCE</label>
                            <input type="text" class="form-input" name="s_experience" id="s_experience" placeholder="Experience" />
                            <span id="s_experience" style="color:red"></span>
                        </div>

                        <div class="form-group">
                         <label>AADHAR NUMBER</label>
                            <input type="number" class="form-input" name="s_aadhar" id="s_aadhar" placeholder="Aadhar Number" />
                            <span id="s_aadhar" style="color:red"></span>
                        </div>
                    
                        <div class="form-group">
                         <label>UPLOAD AADHAR</label>
                            <input type="file" class="form-input" name="s_upaadhar" id="s_upaadhar" placeholder="" />
                            <span id="s_upaadhar" style="color:red"></span>
                        </div>

                         <div class="form-group">
                        <label>USER NAME</label>
                            <input type="text" class="form-input" name="uname" id="uname" placeholder="3 Digit Id"/>  
                            <span id="uname" style="color:red"></span>
                       
                        </div>

                        <div class="form-group">
                        <label>PASSWORD</label>
                            <input type="password" class="form-input" name="pwd" id="pwd" placeholder="Password" />
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>    
                            <span id="pwd" style="color:red"></span>          
                        </div> 
                        
						 <div class="form-group">
        
            <label>ROLE</label>
            <select id="role" name="role" class="form-control" required>
              <option value="select" selected disabled>select</option> 
              <option value="staff">STAFF</option>
              </select>
              <span id="role"></span>
          </div> 
		  
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="ADD STAFF"/>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
   
   

</body>
</html>
<?php
if(isset($_POST['submit']))
{
    $s_name = $_POST['s_name'];
    $s_place=$_POST['s_place'];
    $s_pin = $_POST['s_pin'];
    $s_gender=$_POST['s_gender'];
    $s_email=$_POST['s_email'];
    $s_qualification=$_POST['s_qualification'];
    $s_phone=$_POST['s_phone'];
    $s_experience=$_POST['s_experience'];
    $s_aadhar=$_POST['s_aadhar'];
    $s_upaadhar=$_POST['s_upaadhar'];
	$uname=$_POST['uname'];
    $pwd=$_POST['pwd'];
    $role=$_POST['role'];

    
    $sql=mysqli_query($connection,"INSERT INTO `tbl_login`( `uname`,`pwd`,`role`) VALUES ('$uname','$pwd','$role')");
    $roleid=mysqli_insert_id($connection);
    $sq=mysqli_query($connection,"INSERT INTO `add_staff`( `login_id`, `s_name`, `s_place`, `s_pin`, `s_gender`, `s_email`, `s_qualification`, `s_phone`,`s_experience`,`s_aadhar`,`s_upaadhar`) VALUES ('$roleid','$s_name','$s_place','$s_pin','$s_gender','$s_email','$s_qualification','$s_phone','$s_experience','$s_aadhar','$s_upaadhar')");
  // @header("location:login.php");
echo "<script>location='login.php'</script>";
}
?>